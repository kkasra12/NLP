from .wordTokenizer import wordTokenizer,wordCounter
from .tokens import Token

__version__ = '1.0.0'
