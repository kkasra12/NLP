from .documentsStaticals import TF,DF,TF_IDF,DF_fromTF

__version__="1.1.0"
